
package com.example.android.TourAppVolos;

public class Place {

    /** String resource ID for the place */
    private int mName;

    /** String resource ID for the address*/
    private int mAddress;


    /** Image resource ID for the word */
    private int mImageResourceId = NO_IMAGE_PROVIDED;

    /** Constant value that represents no image was provided for this word */
    private static final int NO_IMAGE_PROVIDED = -1;




    /**
     * Create a new Place object.
     *  @param name is the name of the place or sight
     * @param address is the address of the place
     */
    public Place(int name, int address, int imageResourceId) {
        mName = name;
        mAddress = address;
        mImageResourceId = imageResourceId;

    }

    /**
     * Get the name of the place
     */
    public int getName() {
        return mName;
    }

    /**
     * Get the address of the place
     */
    public int getAddress() {
        return mAddress;
    }

    /**
     * Return the image resource ID of the place.
     */
    public int getImageResourceId() {
        return mImageResourceId;
    }

    /**
     * Returns whether or not there is an image for place.
     */
    public boolean hasImage() {
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }


}